
"use strict";

let Digital = require('./Digital.js');
let Analog = require('./Analog.js');

module.exports = {
  Digital: Digital,
  Analog: Analog,
};
